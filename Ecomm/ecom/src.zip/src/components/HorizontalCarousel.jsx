// // // // import { useRef } from "react";
// // // // import { cn } from "../utils/cn";

// // // // export default function HorizontalCarousel({ children, className }) {
// // // //   const ref = useRef(null);
// // // //   const scroll = (dir) => {
// // // //     const el = ref.current;
// // // //     if (!el) return;
// // // //     const amount = el.clientWidth * 0.9;
// // // //     el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
// // // //   };

// // // //   return (
// // // //     <div className={cn("relative", className)}>
// // // //       <button
// // // //         className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-10 btn-ghost rounded-full w-10 h-10"
// // // //         onClick={() => scroll("left")}
// // // //         aria-label="Scroll left"
// // // //       >‹</button>
// // // //       <div
// // // //         ref={ref}
// // // //         className="flex gap-4 overflow-x-auto snap-x snap-mandatory scroll-smooth pb-2"
// // // //       >
// // // //         {children}
// // // //       </div>
// // // //       <button
// // // //         className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-10 btn-ghost rounded-full w-10 h-10"
// // // //         onClick={() => scroll("right")}
// // // //         aria-label="Scroll right"
// // // //       >›</button>
// // // //     </div>
// // // //   );
// // // // }
// // // import { useRef } from "react";
// // // import cn from "../utils/cn";

// // // export default function HorizontalCarousel({ children, className }) {
// // //   const ref = useRef(null);

// // //   const scroll = (dir) => {
// // //     const el = ref.current;
// // //     if (!el) return;
// // //     const amount = el.clientWidth * 0.8;
// // //     el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
// // //   };

// // //   return (
// // //     <div className={cn("relative py-4", className)}>
// // //       {/* Left Arrow */}
// // //       <button
// // //         onClick={() => scroll("left")}
// // //         className="
// // //           hidden md:flex absolute left-2 top-1/2 -translate-y-1/2 z-20 
// // //           bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
// // //           items-center justify-center border text-xl
// // //         "
// // //       >
// // //         ‹
// // //       </button>

// // //       {/* Scrollable container */}
// // //       <div
// // //         ref={ref}
// // //         className="
// // //           flex gap-6 overflow-x-auto scroll-smooth px-2
// // //           snap-x snap-mandatory
// // //           [&::-webkit-scrollbar]:hidden
// // //         "
// // //       >
// // //         {children}
// // //       </div>

// // //       {/* Right Arrow */}
// // //       <button
// // //         onClick={() => scroll("right")}
// // //         className="
// // //           hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 z-20 
// // //           bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
// // //           items-center justify-center border text-xl
// // //         "
// // //       >
// // //         ›
// // //       </button>
// // //     </div>
// // //   );
// // // }

// // import { useRef } from "react";
// // import cn from "../utils/cn";

// // export default function HorizontalCarousel({ children, className }) {
// //   const ref = useRef(null);

// //   const scroll = (dir) => {
// //     const el = ref.current;
// //     const amount = el.clientWidth * 0.8;
// //     el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
// //   };

// //   return (
// //     <div className={cn("relative py-4", className)}>
// //       <button
// //         onClick={() => scroll("left")}
// //         className="hidden md:flex absolute left-2 top-1/2 -translate-y-1/2 
// //                    z-20 bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
// //                    items-center justify-center border text-xl"
// //       >
// //         ‹
// //       </button>

// //       <div
// //         ref={ref}
// //         className="
// //           flex gap-6 overflow-x-auto scroll-smooth px-2
// //           snap-x snap-mandatory
// //           [&::-webkit-scrollbar]:hidden
// //         "
// //       >
// //         {children}
// //       </div>

// //       <button
// //         onClick={() => scroll("right")}
// //         className="hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 
// //                    z-20 bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
// //                    items-center justify-center border text-xl"
// //       >
// //         ›
// //       </button>
// //     </div>
// //   );
// // }
// import { useNavigate } from 'react-router-dom';
// import ProductCard from './ProductCard.jsx';

// // Minimal CSS expectations (optional):
// // .h-carousel { overflow: hidden; }
// // .h-carousel__track { display: flex; gap: 16px; overflow-x: auto; padding: 8px 0; }
// // .h-carousel__tile { flex: 0 0 auto; cursor: pointer; }
// // .h-carousel__header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }

// export default function HorizontalCarousel({
//   products = [],
//   title,
//   className = '',
// }) {
//   const navigate = useNavigate();

//   const onTileKeyDown = (e, id) => {
//     // Make tiles keyboard-activatable for accessibility
//     if (e.key === 'Enter' || e.key === ' ') {
//       e.preventDefault();
//       navigate(`/product/${id}`);
//     }
//   };

//   if (!Array.isArray(products) || products.length === 0) {
//     return (
//       <section className={`h-carousel ${className}`}>
//         {title ? <div className="h-carousel__header"><h2>{title}</h2></div> : null}
//         <div className="h-carousel__empty">No products to show.</div>
//       </section>
//     );
//   }

//   return (
//     <section className={`h-carousel ${className}`}>
//       {title ? (
//         <div className="h-carousel__header">
//           <h2>{title}</h2>
//         </div>
//       ) : null}

//       <div className="h-carousel__track">
//         {products.map((p) => (
//           <div
//             key={p.id ?? p.productId ?? p.sku ?? p._id}
//             className="h-carousel__tile"
//             role="button"
//             tabIndex={0}
//             onClick={() => navigate(`/product/${p.id ?? p.productId ?? p.sku ?? p._id}`)}
//             onKeyDown={(e) => onTileKeyDown(e, p.id ?? p.productId ?? p.sku ?? p._id)}
//             aria-label={`Open ${p.title ?? p.name ?? 'product'}`}
//           >
//             {/* ProductCard renders the Add-to-cart button internally.
//                 Its button calls e.stopPropagation() so clicking it won't navigate. */}
//             <ProductCard product={p} />
//           </div>
//         ))}
//       </div>
//     </section>
//   );
// }

import { useNavigate } from 'react-router-dom';
import ProductCard from './ProductCard.jsx';

// Minimal CSS expectations (optional):
// .h-carousel { overflow: hidden; }
// .h-carousel__header { display:flex; align-items:center; justify-content:space-between; margin-bottom: 8px; }
// .h-carousel__track { display:flex; gap:16px; overflow-x:auto; padding:8px 0; }
// .h-carousel__tile { flex:0 0 auto; cursor:pointer; }

export default function HorizontalCarousel({
  products = [],
  title,
  className = '',
}) {
  const navigate = useNavigate();

  const onTileKeyDown = (e, pid) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      navigate(`/product/${pid}`);
    }
  };

  // Guard array and filter out null/undefined entries
  const safeProducts = (Array.isArray(products) ? products : []).filter(Boolean);

  if (safeProducts.length === 0) {
    return (
      <section className={`h-carousel ${className}`}>
        {title ? <div className="h-carousel__header"><h2>{title}</h2></div> : null}
        <div className="h-carousel__empty">No products to show.</div>
      </section>
    );
  }

  return (
    <section className={`h-carousel ${className}`}>
      {title ? (
        <div className="h-carousel__header">
          <h2>{title}</h2>
        </div>
      ) : null}

      <div className="h-carousel__track">
        {safeProducts.map((p, idx) => {
          // Compute a safe product id for keys and navigation
          const pid = String(p?.id ?? p?.productId ?? p?.sku ?? p?._id ?? idx);
          const title = p?.title ?? p?.name ?? 'product';

          return (
            <div
              key={pid}
              className="h-carousel__tile"
              role="button"
              tabIndex={0}
              onClick={() => navigate(`/product/${pid}`)}
              onKeyDown={(e) => onTileKeyDown(e, pid)}
              aria-label={`Open ${title}`}
            >
              {/* ProductCard is already safe and will return null for falsy product */}
              <ProductCard product={p} />
            </div>
          );
        })}
      </div>
    </section>
  );
}
