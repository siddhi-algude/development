import Button from "./Button";

export default {
  title: "Components/Button",
  component: Button,
  tags: ["autodocs"],
};

export const Primary = {
  args: {
    children: "Primary Button",
    className: "bg-black text-white px-4 py-2 rounded-lg",
  },
};

export const Ghost = {
  args: {
    children: "Ghost Button",
    className: "border px-4 py-2 rounded-lg",
  },
};
