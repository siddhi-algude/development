import ProductCard from "./ProductCard";

export default {
  title: "Components/ProductCard",
  component: ProductCard,
  tags: ["autodocs"],
};

export const Default = {
  args: {
    product: {
      id: 1,
      title: "Sample Product",
      price: 199,
      image: "https://via.placeholder.com/200",
      rating: 4.5,
      stock: 10,
    },
  },
};

export const OutOfStock = {
  args: {
    product: {
      id: 2,
      title: "Out of Stock Product",
      price: 299,
      image: "https://via.placeholder.com/200",
      rating: 4.0,
      stock: 0,
    },
  },
};
