// // // import { createContext, useContext, useMemo, useReducer } from "react";
// // // import { useLocalStorage } from "../hooks/useLocalStorage";

// // // const CartContext = createContext(null);

// // // function cartReducer(state, action) {
// // //   switch (action.type) {
// // //     case "ADD": {
// // //       const { product, qty } = action;
// // //       const idx = state.items.findIndex(i => i.id === product.id);
// // //       const items = [...state.items];
// // //       if (idx >= 0) items[idx] = { ...items[idx], qty: items[idx].qty + qty };
// // //       else items.push({ id: product.id, title: product.title, price: product.price, image: product.image, qty });
// // //       return { ...state, items };
// // //     }
// // //     case "SET_QTY": {
// // //       const { id, qty } = action;
// // //       const items = state.items.map(i => i.id === id ? { ...i, qty } : i).filter(i => i.qty > 0);
// // //       return { ...state, items };
// // //     }
// // //     case "REMOVE": {
// // //       const items = state.items.filter(i => i.id !== action.id);
// // //       return { ...state, items };
// // //     }
// // //     case "CLEAR":
// // //       return { items: [] };
// // //     default:
// // //       return state;
// // //   }
// // // }

// // // export function CartProvider({ children }) {
// // //   const [persisted, setPersisted] = useLocalStorage("cart_v1", { items: [] });
// // //   const [state, dispatch] = useReducer(cartReducer, persisted);

// // //   // persist on change
// // //   useMemo(() => setPersisted(state), [state, setPersisted]);

// // //   const totalCount = useMemo(() => state.items.reduce((s, i) => s + i.qty, 0), [state]);
// // //   const subtotal   = useMemo(() => state.items.reduce((s, i) => s + i.price * i.qty, 0), [state]);

// // //   // Math story: 10% tax, shipping $0 if subtotal >= $50 else $5
// // //   const taxRate = 0.10;
// // //   const tax = useMemo(() => subtotal * taxRate, [subtotal]);
// // //   const shipping = useMemo(() => (subtotal > 0 && subtotal < 50 ? 5 : 0), [subtotal]);
// // //   const total = useMemo(() => subtotal + tax + shipping, [subtotal, tax, shipping]);

// // //   const value = useMemo(() => ({
// // //     items: state.items,
// // //     addItem: (product, qty = 1) => dispatch({ type: "ADD", product, qty }),
// // //     setQty: (id, qty) => dispatch({ type: "SET_QTY", id, qty }),
// // //     removeItem: (id) => dispatch({ type: "REMOVE", id }),
// // //     clear: () => dispatch({ type: "CLEAR" }),
// // //     totalCount, subtotal, tax, shipping, total, taxRate,
// // //   }), [state.items, totalCount, subtotal, tax, shipping, total]);

// // //   return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
// // // }

// // // export function useCart() {
// // //   const ctx = useContext(CartContext);
// // //   if (!ctx) throw new Error("useCart must be used inside CartProvider");
// // //   return ctx;
// // // }

// // import { createContext, useContext, useState } from "react";

// // const CartContext = createContext();

// // export function CartProvider({ children }) {
// //   const [cart, setCart] = useState([]);

// //   // ADD TO CART
// //   function addItem(product) {
// //     setCart(prev => {
// //       const exists = prev.find(item => item.id === product.id);

// //       if (exists) {
// //         return prev.map(item =>
// //           item.id === product.id
// //             ? { ...item, quantity: item.quantity + 1 }
// //             : item
// //         );
// //       }

// //       return [...prev, { ...product, quantity: 1 }];
// //     });
// //   }

// //   // UPDATE QUANTITY
// //   function updateItem(id, quantity) {
// //     setCart(prev => {
// //       if (quantity <= 0) {
// //         return prev.filter(item => item.id !== id);
// //       }

// //       return prev.map(item =>
// //         item.id === id ? { ...item, quantity } : item
// //       );
// //     });
// //   }

// //   // REMOVE ITEM
// //   function removeItem(id) {
// //     setCart(prev => prev.filter(item => item.id !== id));
// //   }

// //   // CLEAR CART
// //   function clearCart() {
// //     setCart([]);
// //   }

// //   return (
// //     <CartContext.Provider
// //       value={{ cart, addItem, updateItem, removeItem, clearCart }}
// //     >
// //       {children}
// //     </CartContext.Provider>
// //   );
// // }

// // export function useCart() {
// //   return useContext(CartContext);
// // }

// import { createContext, useContext, useMemo } from 'react';
// import useLocalStorage from '../hooks/useLocalStorage.js';

// const CartContext = createContext(null);

// // Cart item shape: { id, title, price, image, qty }

// export function CartProvider({ children }) {
//   // Always start with an array; never undefined
//   const [items, setItems] = useLocalStorage('cart:v1', []);

//   const addItem = (product, qty = 1) => {
//     if (!product || product.id == null) return;

//     setItems(prev => {
//       const list = Array.isArray(prev) ? [...prev] : [];
//       const index = list.findIndex(i => i.id === product.id);

//       if (index >= 0) {
//         const next = [...list];
//         const currentQty = Number(next[index].qty) || 0;
//         next[index] = { ...next[index], qty: currentQty + (Number(qty) || 1) };
//         return next;
//       }

//       // Try to pick a reasonable image key if your schema varies
//       const image =
//         product.image ||
//         product.thumbnail ||
//         (Array.isArray(product.images) ? product.images[0] : undefined);

//       return [
//         ...list,
//         {
//           id: product.id,
//           title: product.title ?? product.name ?? `Product ${product.id}`,
//           price: Number(product.price) || 0,
//           image,
//           qty: Number(qty) || 1,
//         },
//       ];
//     });
//   };

//   const removeItem = (id) => {
//     setItems(prev => (Array.isArray(prev) ? prev.filter(i => i.id !== id) : []));
//   };

//   const updateQty = (id, qty) => {
//     setItems(prev => {
//       const list = Array.isArray(prev) ? [...prev] : [];
//       const index = list.findIndex(i => i.id === id);
//       if (index === -1) return list;

//       const safeQty = Math.max(0, Number(qty) || 0);
//       if (safeQty === 0) return list.filter(i => i.id !== id);

//       const next = [...list];
//       next[index] = { ...next[index], qty: safeQty };
//       return next;
//     });
//   };

//   const clear = () => setItems([]);

//   const derived = useMemo(() => {
//     const safe = Array.isArray(items) ? items : [];
//     const count = safe.reduce((acc, i) => acc + (Number(i.qty) || 0), 0);
//     const subtotal = safe.reduce(
//       (acc, i) => acc + (Number(i.qty) || 0) * (Number(i.price) || 0),
//       0
//     );
//     return { items: safe, count, subtotal };
//   }, [items]);

//   const value = useMemo(
//     () => ({
//       ...derived,
//       addItem,
//       removeItem,
//       updateQty,
//       clear,
//     }),
//     [derived]
//   );

//   return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
// }

// export function useCart() {
//   const ctx = useContext(CartContext);
//   if (!ctx) {
//     throw new Error(
//       'useCart must be used within <CartProvider>. Make sure CartProvider wraps your app.'
//     );
//   }
//   return ctx;
// }
import { createContext, useContext, useMemo } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage.js';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useLocalStorage('cart:v1', []);

  const addItem = (product, qty = 1) => {
    if (!product || product.id == null) return;
    setItems(prev => {
      const list = Array.isArray(prev) ? [...prev] : [];
      const index = list.findIndex(i => i.id === product.id);
      if (index >= 0) {
        const next = [...list];
        const currentQty = Number(next[index].qty) || 0;
        next[index] = { ...next[index], qty: currentQty + (Number(qty) || 1) };
        return next;
      }
      const image =
        product.image ||
        product.thumbnail ||
        (Array.isArray(product.images) ? product.images[0] : undefined);

      return [
        ...list,
        {
          id: product.id,
          title: product.title ?? product.name ?? `Product ${product.id}`,
          price: Number(product.price) || 0,
          image,
          qty: Number(qty) || 1,
        },
      ];
    });
  };

  const removeItem = (id) => {
    setItems(prev => (Array.isArray(prev) ? prev.filter(i => i.id !== id) : []));
  };

  const updateQty = (id, qty) => {
    setItems(prev => {
      const list = Array.isArray(prev) ? [...prev] : [];
      const index = list.findIndex(i => i.id === id);
      if (index === -1) return list;

      const safeQty = Math.max(0, Number(qty) || 0);
      if (safeQty === 0) return list.filter(i => i.id !== id);

      const next = [...list];
      next[index] = { ...next[index], qty: safeQty };
      return next;
    });
  };

  const clear = () => setItems([]);

  const derived = useMemo(() => {
    const safe = Array.isArray(items) ? items : [];
    const count = safe.reduce((acc, i) => acc + (Number(i.qty) || 0), 0);
    const subtotal = safe.reduce(
      (acc, i) => acc + (Number(i.qty) || 0) * (Number(i.price) || 0),
      0
    );
    return { items: safe, count, subtotal };
  }, [items]);

  const value = useMemo(
    () => ({ ...derived, addItem, removeItem, updateQty, clear }),
    [derived]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error('useCart must be used within <CartProvider>. Make sure CartProvider wraps your app.');
  }
  return ctx;
}
