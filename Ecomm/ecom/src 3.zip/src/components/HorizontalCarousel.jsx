 
// import { useRef } from "react";
// import cn from "../utils/cn";

// export default function HorizontalCarousel({ children, className }) {
//   const ref = useRef(null);

//   const scroll = (dir) => {
//     const el = ref.current;
//     const amount = el.clientWidth * 0.8;
//     el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
//   };

//   return (
//     <div className={cn("relative py-4", className)}>
//       <button
//         onClick={() => scroll("left")}
//         className="hidden md:flex absolute left-2 top-1/2 -translate-y-1/2 
//                    z-20 bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
//                    items-center justify-center border text-xl"
//       >
//         ‹
//       </button>

//       <div
//         ref={ref}
//         className="
//           flex gap-6 overflow-x-auto scroll-smooth px-2
//           snap-x snap-mandatory
//           [&::-webkit-scrollbar]:hidden
//         "
//       >
//         {children}
//       </div>

//       <button
//         onClick={() => scroll("right")}
//         className="hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 
//                    z-20 bg-white shadow hover:shadow-lg rounded-full w-10 h-10 
//                    items-center justify-center border text-xl"
//       >
//         ›
//       </button>
//     </div>
//   );
// }
import { useRef } from "react";

export default function HorizontalCarousel({ children }) {
  const scrollRef = useRef(null);

  const scroll = (offset) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({
      left: offset,
      behavior: "smooth",
    });
  };

  return (
    <div className="relative w-full">

      {/* LEFT BUTTON */}
      <button
        onClick={() => scroll(-300)}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full shadow p-2"
      >
        &#8249;
      </button>

      {/* VIEWPORT */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scroll-smooth no-scrollbar px-10"
        style={{ scrollSnapType: "x mandatory" }}
      >
        {children.map((child, i) => (
          <div
            key={i}
            className="shrink-0 scroll-snap-start"
            style={{ width: "200px" }}
          >
            {child}
          </div>
        ))}
      </div>

      {/* RIGHT BUTTON */}
      <button
        onClick={() => scroll(300)}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full shadow p-2"
      >
        &#8250;
      </button>

    </div>
  );
}
